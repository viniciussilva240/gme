import { proxyFetch, API_BASE_URL } from "@/lib/apiProxy";

const API_BASE = `${API_BASE_URL}/ordens-servico`;

// POST /ordens/:id/concluir — conclui a OS, atualiza estoque e calcula valor total
export async function POST(_, { params }) {
  const { id } = await params;
  return proxyFetch(`${API_BASE}/${id}/concluir`, {
    method: "POST",
    headers: { "Accept": "application/json" },
  });
}
