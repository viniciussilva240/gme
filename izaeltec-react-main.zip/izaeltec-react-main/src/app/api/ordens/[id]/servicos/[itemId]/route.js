import { proxyFetch, API_BASE_URL } from "@/lib/apiProxy";

const API_BASE = `${API_BASE_URL}/ordens-servico`;

// DELETE /ordens/:id/servicos/:itemId — remove o vínculo de serviço (itemId = id do vínculo)
export async function DELETE(_, { params }) {
  const { id, itemId } = await params;
  return proxyFetch(`${API_BASE}/${id}/servicos/${itemId}`, { method: "DELETE" });
}
