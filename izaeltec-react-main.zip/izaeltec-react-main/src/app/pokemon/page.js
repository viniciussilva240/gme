"use client";

import { useState, useEffect } from "react";

const LIMIT = 9;
const BASE  = "https://pokeapi.co/api/v2/pokemon";

// Extrai o ID do pokémon a partir da URL da PokéAPI
function idFromUrl(url) {
  const parts = url.replace(/\/$/, "").split("/");
  return parts[parts.length - 1];
}

// Sprite oficial
function spriteUrl(id) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
}

// Paleta de tipos (exibição visual simples)
const TYPE_COLORS = {
  fire:     "#f97316", water:    "#3b82f6", grass:    "#22c55e",
  electric: "#eab308", psychic:  "#a855f7", ice:      "#67e8f9",
  dragon:   "#6366f1", dark:     "#374151", fairy:    "#ec4899",
  normal:   "#94a3b8", fighting: "#dc2626", flying:   "#7dd3fc",
  poison:   "#a855f7", ground:   "#d97706", rock:     "#78716c",
  bug:      "#84cc16", ghost:    "#6d28d9", steel:    "#64748b",
};

function typeColor(t) { return TYPE_COLORS[t] ?? "#94a3b8"; }

export default function PokemonPage() {
  const [lista,   setLista]   = useState([]);   // lista básica (nome + url)
  const [detalhes,setDetalhes]= useState({});   // { id: { tipos, sprite } }
  const [offset,  setOffset]  = useState(0);
  const [total,   setTotal]   = useState(0);
  const [search,  setSearch]  = useState("");
  const [loading, setLoading] = useState(true);
  const [erro,    setErro]    = useState(null);

  // Busca a página atual
  useEffect(() => {
    let cancelled = false;
    async function fetchPage() {
      setLoading(true); setErro(null);
      try {
        const res  = await fetch(`${BASE}?offset=${offset}&limit=${LIMIT}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (!cancelled) {
          setLista(data.results);
          setTotal(data.count);
          // busca detalhes (tipos) de cada pokémon em paralelo
          const promises = data.results.map((p) =>
            fetch(p.url).then((r) => r.json()).catch(() => null)
          );
          const dets = await Promise.all(promises);
          if (!cancelled) {
            const map = {};
            dets.forEach((d) => {
              if (!d) return;
              map[d.id] = { tipos: d.types.map((t) => t.type.name) };
            });
            setDetalhes(map);
          }
        }
      } catch (e) {
        if (!cancelled) setErro("Não foi possível carregar os pokémons.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    fetchPage();
    return () => { cancelled = true; };
  }, [offset]);

  // Filtro local por nome
  const filtered = lista.filter((p) =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const totalPages = Math.ceil(total / LIMIT);
  const currentPage = Math.floor(offset / LIMIT) + 1;

  return (
    <div style={{ minHeight: "100vh", background: "#f8fafc", fontFamily: "DM Sans, sans-serif", padding: "32px 24px" }}>
      {/* Header */}
      <div style={{ maxWidth: 900, margin: "0 auto" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 8 }}>
          <img
            src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/poke-ball.png"
            alt="pokeball"
            style={{ width: 36, height: 36, imageRendering: "pixelated" }}
          />
          <h1 style={{ fontSize: 28, fontWeight: 800, color: "#0f172a", margin: 0 }}>Pokédex</h1>
        </div>
        <p style={{ color: "#64748b", fontSize: 14, marginBottom: 24, marginTop: 4 }}>
          {total > 0 ? `${total} pokémons encontrados` : "Carregando..."}
        </p>

        {/* Busca */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, background: "#fff", border: "1.5px solid #e2e8f0", borderRadius: 10, padding: "10px 16px", marginBottom: 28, maxWidth: 400 }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth={2} width={16} height={16}>
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            style={{ border: "none", outline: "none", fontSize: 14, color: "#0f172a", background: "transparent", width: "100%", fontFamily: "DM Sans, sans-serif" }}
            placeholder="Buscar por nome..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          {search && (
            <button onClick={() => setSearch("")} style={{ background: "none", border: "none", cursor: "pointer", color: "#94a3b8", padding: 0, lineHeight: 1 }}>✕</button>
          )}
        </div>

        {/* Erro */}
        {erro && (
          <div style={{ background: "#fff0f3", border: "1px solid #fecdd3", color: "#b1002f", borderRadius: 10, padding: "12px 16px", marginBottom: 24, fontSize: 14 }}>
            {erro}
          </div>
        )}

        {/* Grid */}
        {loading ? (
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: 240, gap: 12, color: "#64748b", fontSize: 14 }}>
            <div style={{ width: 22, height: 22, border: "3px solid #e2e8f0", borderTopColor: "#b1002f", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
            Carregando pokémons...
            <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
          </div>
        ) : (
          <>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 16, marginBottom: 32 }}>
              {filtered.map((p) => {
                const id    = idFromUrl(p.url);
                const det   = detalhes[Number(id)];
                const tipos = det?.tipos ?? [];
                const cor   = typeColor(tipos[0]);
                return (
                  <div
                    key={p.name}
                    style={{
                      background: "#fff",
                      border: "1.5px solid #e2e8f0",
                      borderRadius: 16,
                      overflow: "hidden",
                      boxShadow: "0 1px 4px rgba(0,0,0,.06)",
                      transition: "transform .15s, box-shadow .15s",
                      cursor: "default",
                    }}
                    onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 6px 20px rgba(0,0,0,.1)"; }}
                    onMouseLeave={(e) => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = "0 1px 4px rgba(0,0,0,.06)"; }}
                  >
                    {/* Banner colorido */}
                    <div style={{ background: `${cor}18`, height: 100, display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
                      <img
                        src={spriteUrl(id)}
                        alt={p.name}
                        style={{ height: 90, width: 90, objectFit: "contain", position: "absolute", bottom: -10 }}
                        loading="lazy"
                      />
                      <span style={{ position: "absolute", top: 10, right: 12, fontSize: 12, fontWeight: 700, color: "#94a3b8" }}>
                        #{String(id).padStart(4, "0")}
                      </span>
                    </div>

                    <div style={{ padding: "22px 16px 16px" }}>
                      <p style={{ margin: "0 0 10px", fontWeight: 700, fontSize: 16, color: "#0f172a", textTransform: "capitalize" }}>
                        {p.name}
                      </p>
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                        {tipos.length === 0 ? (
                          <span style={{ fontSize: 11, color: "#cbd5e1" }}>—</span>
                        ) : tipos.map((t) => (
                          <span
                            key={t}
                            style={{
                              fontSize: 11, fontWeight: 600, textTransform: "capitalize",
                              background: `${typeColor(t)}20`, color: typeColor(t),
                              padding: "3px 10px", borderRadius: 20,
                              border: `1px solid ${typeColor(t)}40`,
                            }}
                          >
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
              {filtered.length === 0 && !loading && (
                <p style={{ color: "#94a3b8", fontSize: 14, gridColumn: "1/-1", textAlign: "center", padding: "40px 0" }}>
                  Nenhum pokémon encontrado para "{search}".
                </p>
              )}
            </div>

            {/* Paginação */}
            {!search && (
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 12 }}>
                <button
                  onClick={() => setOffset(Math.max(0, offset - LIMIT))}
                  disabled={offset === 0}
                  style={{ padding: "8px 20px", background: offset === 0 ? "#f1f5f9" : "#0f172a", color: offset === 0 ? "#cbd5e1" : "#fff", border: "none", borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: offset === 0 ? "not-allowed" : "pointer", fontFamily: "DM Sans, sans-serif" }}
                >
                  ← Anterior
                </button>
                <span style={{ fontSize: 14, color: "#64748b", minWidth: 100, textAlign: "center" }}>
                  {currentPage} / {totalPages}
                </span>
                <button
                  onClick={() => setOffset(offset + LIMIT)}
                  disabled={offset + LIMIT >= total}
                  style={{ padding: "8px 20px", background: offset + LIMIT >= total ? "#f1f5f9" : "#0f172a", color: offset + LIMIT >= total ? "#cbd5e1" : "#fff", border: "none", borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: offset + LIMIT >= total ? "not-allowed" : "pointer", fontFamily: "DM Sans, sans-serif" }}
                >
                  Próximo →
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
